import os
from typing import Any, Dict, List, Tuple


class ConfigParser:

    def __init__(self, filepath: str) -> None:
        self.filepath = filepath
        self.config: Dict[str, Any] = {}

    def parse(self) -> Dict[str, Any]:
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"Configuration "
                                    f"file not found: {self.filepath}")

        with open(self.filepath, 'r', encoding='utf-8') as f:
            for lineno, raw_line in enumerate(f, 1):
                line = raw_line.split('#')[0].strip()
                if not line:
                    continue
                if '=' not in line:
                    raise ValueError(
                        f"Line {lineno} is not in 'KEY=VALUE' "
                        f"format: {line}"
                    )
                key, value = line.split('=', 1)
                self._process_kv(key.strip(), value.strip())

        self._validate()
        return self.config

    def _process_kv(self, key: str, value: str) -> None:
        if key in ('WIDTH', 'HEIGHT'):
            self.config[key] = int(value)
        elif key in ('ENTRY', 'EXIT'):
            parts = value.split(',')
            if len(parts) != 2:
                raise ValueError(
                    f"{key} must be in 'x,y' format, got: {value}"
                )
            self.config[key] = (int(parts[0]), int(parts[1]))
        elif key == 'PERFECT':
            lowered = value.lower()
            if lowered in ('true', '1', 'yes'):
                self.config[key] = True
            elif lowered in ('false', '0', 'no'):
                self.config[key] = False
            else:
                raise ValueError(
                    f"PERFECT must be a boolean "
                    f"(True/False), got: {value}"
                )

        elif key == 'SEED':
            if not value or value.lower() == 'none':
                self.config[key] = None
            else:
                self.config[key] = int(value)
        else:
            self.config[key] = value

    def _validate(self) -> None:
        mandatory_keys = ['WIDTH',
                          'HEIGHT',
                          'ENTRY',
                          'EXIT',
                          'OUTPUT_FILE',
                          'PERFECT']
        for k in mandatory_keys:
            if k not in self.config:
                raise ValueError(f"Missing "
                                 f"mandatory configuration key: {k}")
        if self.config['WIDTH'] < 1 or self.config['HEIGHT'] < 1:
            raise ValueError("WIDTH and HEIGHT must be positive integers")

        w = self.config['WIDTH']
        h = self.config['HEIGHT']
        for key in ('ENTRY', 'EXIT'):
            x, y = self.config[key]
            if not (0 <= x < w and 0 <= y < h):
                raise ValueError(
                    f"{key} coordinates {x},{y} are outside the maze"
                )

        if self.config['ENTRY'] == self.config['EXIT']:
            raise ValueError("ENTRY and EXIT must be different cells")

        self.config.setdefault('SEED', None)

    @staticmethod
    def write_maze_output(
        filepath: str,
        walls: List[List[int]],
        entry: Tuple[int, int],
        exit_pos: Tuple[int, int],
        path: str = "",
    ) -> None:
        with open(filepath, "w", encoding="utf-8") as f:
            for row in walls:
                f.write("".join(format(c & 0xF, "x") for c in row) + "\n")

            f.write("\n")
            f.write(f"{entry[0]},{entry[1]}\n")
            f.write(f"{exit_pos[0]},{exit_pos[1]}\n")
            f.write(f"{path}\n")
